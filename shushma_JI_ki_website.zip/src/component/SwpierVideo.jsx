import React from 'react'
import { Swiper, SwiperSlide,} from 'swiper/react';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';

export default function SwpierVideo() {
  return (
    <>
      <section className='grid grid-cols-[43%_auto] '>
      <div className="bg-[url('https://staging.adiyogitechnology.com/sushmagroup/assets/aa3adfea8ebb38b3b1b10f40dabc929a-BGc6J0a9.png')] h-screen bg-no-repeat ps-[38px] flex flex-col justify-center bg-cover">
        <div className='ps-[60px]'>
          <h2 className='text-[40px] lg:text-[45px] xl:text-[50px] text-start xl:leading-[77px] text-white font-semibold'>
            WE MAKE <br /> HOMES THAT <br /> UNDERSTAND <br /> YOU
          </h2>
          <button className='border text-white rounded-3xl px-[45px] py-2 text-[28px] my-[40px]'>SEE ALL PROJECTS</button>
        </div>
      </div>
      <div className='h-full bg-black'>
        
      </div>
    </section>
    </>
  )
}
