import React from 'react'

export default function Aboutsg() {
  return (
    <>
        <section className='grid grid-cols-2 px-[180px] py-[100px] mx-[44px]'>
            <figure><img className='w-[450px]' src="https://staging.adiyogitechnology.com/sushmagroup/assets/46f00ea88134fb2e0b90c47f7672bd3e-CTda4t-G.png" alt="" /></figure>
            <div>
                <h2>About <br />
                Sushma Group</h2>
                <p>
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum
                </p>
                <p>WE PROVIDE YOU THE BEST EXPERIENCE</p>
                <div>
                  <div className='flex flex-col'>
                    <p>100+</p>
                    <p>Completed <br />Project</p>
                  </div>
                </div>
            </div>
        </section>
    </>
  )
}
