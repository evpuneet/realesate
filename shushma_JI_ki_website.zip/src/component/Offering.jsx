import React from 'react'

export default function Offering() {
  return (
    <>
        <section className='text-center'>
            <h2 className='text-[#1e6da4] pt-[100px] text-[40px] font-bold uppercase'>Our Offering</h2>
            <p className='text-[#5a5454] font-medium pb-[80px]'>Within the premises of the Sushma Township are reputed Schools.</p>
            <div className='border-t-[2px] border-t-[#b8c7cb] border-b-[2px] border-b-[#b8c7cb] flex justify-around mb-6 py-[10px]'>
                <div className='text-[#8f9495] text-[22px] font-extrabold'>RESIDENTIAL</div>
                <div className='text-[#8f9495] text-[22px] font-extrabold'>RESIDENTIAL</div>
                <button className='bg-[#1e6da4]'>SEE MORE</button>
            </div>
            <div>
              <figure><img src="https://staging.adiyogitechnology.com/sushmagroup/assets/d172e02422ee757c63b0a92502f6001f-Cd_o3t6P.png" alt="" /></figure>
            </div>
        </section>
    </>
  )
}
