import React from 'react'

export default function BlendCre() {
  return (
    <>
        <section>
            <p>We blend creativity with intelligence to craft homes
            that enhance your living experience and deliver on our promises.</p>
            <div>
                <figure>
                    
                </figure>
            </div>
        </section>
    </>
  )
}
