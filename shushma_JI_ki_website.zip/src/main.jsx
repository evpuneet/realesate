import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import Header from './component/Header'
import SwpierVideo from './component/SwpierVideo'
import Prebout from './component/Prebout'
import Aboutsg from './component/Aboutsg'
import Passion from './component/Passion'
import Whysg from './component/Whysg'
import Offering from './component/Offering'
import Enquire from './component/Enquire'
import Visit from './component/Visit'
import Meet from './component/Meet'
import BlendCre from './component/BlendCre'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <Header/>
    <SwpierVideo/>
    <Prebout/>
    <Aboutsg/>
    <Passion/>
    <Whysg/>
    <Offering/>
    <Enquire/>
    <Visit/>
    <Meet/>
    <BlendCre/>
  </StrictMode>,
)
